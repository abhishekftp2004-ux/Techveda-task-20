import pandas as pd

# Task 20: Data Types and Type Conversion
df = pd.read_csv("passenger_raw.csv")

print("=== ORIGINAL DATA ===")
print(df.head())
print("\\n=== ORIGINAL TYPES ===")
print(df.dtypes)

# Clean common text markers, then convert numeric columns.
df["Age"] = pd.to_numeric(
    df["Age"].astype(str).str.strip().replace({"NA": None, "unknown": None}),
    errors="coerce"
).astype("Int64")

df["Fare"] = pd.to_numeric(
    df["Fare"].astype(str).str.strip().replace({"NA": None}),
    errors="coerce"
)

df["Survived"] = pd.to_numeric(df["Survived"], errors="coerce").astype("Int64")

# Explicitly map text to Boolean.
df["IsStudent"] = df["IsStudent"].map(
    {"True": True, "False": False}
).astype("boolean")

# Parse dates; invalid date strings become NaT.
df["TravelDate"] = pd.to_datetime(df["TravelDate"], errors="coerce")

# Keep category text as a string type.
df["TicketClass"] = df["TicketClass"].astype("string")

print("\\n=== CONVERTED TYPES ===")
print(df.dtypes)
print("\\n=== MISSING VALUES AFTER CONVERSION ===")
print(df.isna().sum())
print("\\n=== CONVERTED DATA ===")
print(df.head(12))

df.to_csv("passenger_cleaned.csv", index=False)
